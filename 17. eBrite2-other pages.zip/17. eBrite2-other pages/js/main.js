(function ($){
	'use strict';

	//Code starts

	/*Menu*/
	$('.menu-icon i').on('click',function(){
		$('.menu').slideToggle();
	})

	$('.menu ul li').on('click',function(){
		
		$(this).children('ul').slideToggle();
	})
	$('.menu ul ul').parent('li').children('a').append('<sup><i class="fas fa-sort-down"></i></sup>');


	/*
	$('.menu ul li').on('click',function(){
		$(this).children('ul').slideToggle();
	})
	$('.menu ul ul').parent('li').children('a').append('<sup><i class="fas fa-sort-down"></i></sup>');
	*/

	//Owl carousel
	$('.header-slider').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})

//owl carousel team slider
		$('.team-slider').owlCarousel({
	    loop:true,
	    margin:10,
	    nav:false,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:1
	        },
	        1000:{
	            items:1
	        }
	    }
	})

		/*******Isotop JS***********/
		$('.filter-button-group').on( 'click', 'button', function() {
		  var filterValue = $(this).attr('data-filter');
		  $grid.isotope({ filter: filterValue });
		});



		var $grid=$('.grid').isotope({
		  // set itemSelector so .grid-sizer is not used in layout
		  itemSelector: '.grid-item',
		  percentPosition: true,
		  masonry: {
		    // use element for option
		    columnWidth: '.grid-item'
		  }
		})

		$('.service-button button').on('click',function(){
			$('.service-button button').removeClass('current');
			$(this).addClass('current');

		})

	
}) (jQuery);



